Learning nix through experimentation
